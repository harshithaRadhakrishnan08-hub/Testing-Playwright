import { When, Then} from '@cucumber/cucumber'

import { pageFixture } from '../hooks/pageFixture'

import { EventLoginPage } from '../Pages/EventLoginPage'

import { userDetails } from '../TestData/eventLogin.json'

let elp:EventLoginPage

When('Open the EventsHub Page',async function(){
    await pageFixture.page.goto('https://eventhub.rahulshettyacademy.com/login')
});

Then('Enter login details with {string} and {string}',async function(username:string,password:string){
    elp=new EventLoginPage(pageFixture.page)

    await elp.waitPage()
    await pageFixture.page.waitForTimeout(2000)
    await elp.elementAssertion()
    await pageFixture.page.waitForTimeout(2000)
    await elp.eventLogin(username,password)
    // await elp.eventLogin(userDetails.userId,userDetails.password)
    await pageFixture.page.waitForTimeout(2000)
})